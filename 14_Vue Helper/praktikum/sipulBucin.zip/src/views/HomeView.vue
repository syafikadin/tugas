<template>
  <div class="home">
    <h1>To Do List</h1>
    <p v-if="toDoList.length == 0">Data Masih Kosong!</p>

    <ol>
        <li v-for="(list, index) in toDoList" :key="list">
            <router-link @click="getIndex(index,list)" :to="'/deskripsi/id' + index">{{ list }}</router-link>
            <button class="buttonHapus" @click="deleteToDoList(index)">Hapus</button>
            <button class="buttonEdit" @click="getIndex(index, list)">Edit</button>
        </li>
    </ol>
    
    <input type="text" v-model="message">

    <div v-if="modeEdit">
        <button @click="updateIndex(message)">Perbarui</button>
    </div>

    <div v-else>
        <button v-on:click="addToDoList(message)" class="buttonUtama">Tambahkan</button>
    </div>

    <p v-if="toDoList.length >= 4">Hebat!</p>

  </div>
</template>

<script>

export default {
    computed: {
        toDoList(){
            return this.$store.state.toDoList
        }
    },
    data(){
        return {
            message: "",
            modeEdit: false,
            indexNumber: null
        }
    },
    methods: {
        addToDoList(){
            this.$store.dispatch('addToDoList', this.message)
            this.message = ''
        },
        deleteToDoList(message){
            this.$store.dispatch('deleteToDoList', message)
        },
        getIndex(index, message){
            this.modeEdit = true
            this.message = message
            this.$store.dispatch('getIndex', index)
        },
        updateIndex(index, message){
            this.$store.dispatch('updateIndex', index, message)
            this.message = ''
            this.modeEdit = false
        }
    },
}
</script>